# SVD issues fixed

Manual fixes to SVD file, done by iteratively comparing with LPC13xx User Manual.

 - `EDGECT32B1_MAT1`: wrong name (`MAT0` duplication)
 - `EDGECT16B0_MAT1`: wrong name (`MAT0` duplication)
 - `BODINTVAL`: duplicate level names (`THE_INTERRUPT_ASSERT`)
 - `BODRSTLEV`: duplicate level names (`THE_INTERRUPT_ASSERT`)
 - `RILOC`: duplicate names (`SELECTS_RI_FUNCTION_` and `RESERVED_`)
 - `DCDLOC`: duplicate names (`RESERVED_`)
 - `SCKLOC`: duplicate names (`SELECTS_SCK0_FUNCTIO`)
 - `DSRLOC`: duplicate names (`SELECTS_DSR_FUNCTION_` and `RESERVED_`)
 - all `enumeratedValues`: dropped non-unique `ENUM` labels
